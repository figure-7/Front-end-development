package com.atguigu.ticket.service;

public interface TicketService {

    public String getTicket();
}
